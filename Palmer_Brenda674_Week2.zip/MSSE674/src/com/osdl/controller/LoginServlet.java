/**
 * 
 */
package com.osdl.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.osdl.bean.LoginBean;
import com.osdl.dao.LoginDao;

/**
 * @author Brenda Palmer
 *
 */

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 102831973239L;

	LoginBean loginBean = new LoginBean("brenda", "pass");

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {

		String userName = "brenda";

		String username1 = loginBean.setUserName(req.getParameter("username"));
		String pass1 = loginBean.setPassword(req.getParameter("pw"));

		if (username1.equalsIgnoreCase(userName)) {
			RequestDispatcher rd = req.getRequestDispatcher("Search.html");
			rd.include(req, res);
			System.out.println("You have been successfully authenticated");

		} else {
			RequestDispatcher rd = req.getRequestDispatcher("Login.html");
			rd.forward(req, res);
			System.out.println("Login failed, please try again");

		}

	}

}
