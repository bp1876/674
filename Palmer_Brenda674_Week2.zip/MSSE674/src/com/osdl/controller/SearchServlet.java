/**
 * 
 */
package com.osdl.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.osdl.bean.SearchBean;

/**
 * @author Brenda Palmer
 *
 */
public class SearchServlet extends HttpServlet {

	private static final long serialVersionUID = 102531973239L;

	SearchBean sb = new SearchBean("Java", "beginner");

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		// String language = req.getParameter("language");
		// String skill = req.getParameter("skill");

		String lang = "Java";

		String language1 = sb.setLanguage(req.getParameter("language"));
		String skill1 = sb.setSkill(req.getParameter("skill"));

		if (language1.equalsIgnoreCase(lang)) {
			RequestDispatcher rd = req.getRequestDispatcher("SearchResults.html");
			rd.include(req, res);
			System.out.println("Here is a list of your search results, please select a book to reserve");

		} else {
			RequestDispatcher rd = req.getRequestDispatcher("Search.html");
			rd.forward(req, res);
			System.out.println("Please enter a valid language and skill level");

		}

	}

}
