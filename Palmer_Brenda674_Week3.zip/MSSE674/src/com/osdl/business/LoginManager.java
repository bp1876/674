/**
 * 
 */
package com.osdl.business;

/**
 * @author Brenda Palmer
 *
 */
public class LoginManager {

	public String authenticate(String login) {

		if (login.isEmpty()) {

			return null;
		}

		return "success";
	}

}
