/**
 * 
 */
package com.osdl.business.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.osdl.bean.LoginBean;
import com.osdl.business.LoginManager;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class LoginManagerTest extends TestCase {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testValidLogin() {

		LoginBean login = new LoginBean("brenda", "pass");

		String user = login.getUserName();

		String lm = (String) (new LoginManager()).authenticate(user);

		Assert.assertNotNull("authentication successful", lm);

		System.out.println("testEquals Passed");
	}

	@Test
	public void testInvalidLogin() {

		LoginBean login = new LoginBean("", "");

		String username = login.getUserName();

		String lm = (String) (new LoginManager()).authenticate(username);

		Assert.assertNull("authentication failed", lm);

		System.out.println("testEquals Passed");
	}

}
