/**
 * 
 */
package com.osdl.business.tests;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.osdl.bean.SearchBean;
import com.osdl.business.SearchManager;

import junit.framework.TestCase;

/**
 * @author Brenda Palmer
 *
 */
public class SearchManagerTest extends TestCase{

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testValidSearch() {

		SearchBean search = new SearchBean("brenda", "pass");

		String lang = search.getLanguage();

		String sm = (String) (new SearchManager()).search(lang);

		Assert.assertNotNull("search criteria valid", sm);

		System.out.println("testEquals Passed");
	}

	@Test
	public void testInvalidSearch() {

		SearchBean search = new SearchBean("", "");

		String lang = search.getLanguage();

		String sm = (String) (new SearchManager()).search(lang);

		Assert.assertNull("search criteria failed", sm);

		System.out.println("testEquals Passed");
	}

}
