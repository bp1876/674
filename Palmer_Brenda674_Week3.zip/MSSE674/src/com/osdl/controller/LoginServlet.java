/**
 * 
 */
package com.osdl.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.osdl.bean.LoginBean;
import com.osdl.business.LoginManager;
import com.osdl.dao.LoginDao;

/**
 * @author Brenda Palmer
 *
 */

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 102431973239L;

	LoginBean loginBean = new LoginBean();

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {

		loginBean.setUserName(req.getParameter("username"));
		String username = loginBean.getUserName();
		// String password = loginBean.setPassword(req.getParameter("pw"));

		LoginManager lm = new LoginManager();

		String user = lm.authenticate(username);

		// Create a session scope for each user
		HttpSession session = req.getSession();
		String name = (String) req.getAttribute("username");
		session.setAttribute("name", name);

		if (user != null) {
			RequestDispatcher rd = req.getRequestDispatcher("Search.html");
			rd.forward(req, res);
			System.out.println("You have been successfully authenticated");

		} else {
			RequestDispatcher rd = req.getRequestDispatcher("LoginError.html");
			rd.forward(req, res);
			System.out.println("Login failed, please try again");

		}

	}

}
